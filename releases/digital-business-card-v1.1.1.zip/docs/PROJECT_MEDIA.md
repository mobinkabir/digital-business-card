# Project media | رسانه‌های پروژه

The preview image is included in this package. The original walkthrough recordings are hosted in the public project repository:

- [Mobile card walkthrough (WebM)](https://github.com/mobinkabir/digital-business-card/blob/main/docs/assets/mobile-card-demo.webm)
- [Admin panel walkthrough (MP4)](https://github.com/mobinkabir/digital-business-card/blob/main/docs/assets/admin-panel-demo.mp4)

The mobile recording visibly includes the sample card's contact details.

تصویر پیش‌نمایش داخل بسته قرار دارد. ویدئوهای اصلی از مخزن عمومی پروژه قابل مشاهده هستند:

- [ویدئوی کارت موبایل](https://github.com/mobinkabir/digital-business-card/blob/main/docs/assets/mobile-card-demo.webm)
- [ویدئوی پنل مدیریت](https://github.com/mobinkabir/digital-business-card/blob/main/docs/assets/admin-panel-demo.mp4)
