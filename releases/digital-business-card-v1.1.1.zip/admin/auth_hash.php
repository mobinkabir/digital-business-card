<?php
declare(strict_types=1);

// Demo first-login credentials for the downloadable distribution.
// Change this password immediately after the first login.
return [
    'username' => 'admin',
    'hash' => '$2y$12$XkQ7CEcK.R2esXC54wlVg.fqjdtVwb4ftCqjs72GI33CKtyWyLE6q',
];
