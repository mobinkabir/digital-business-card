<div dir="rtl">

# کارت ویزیت دیجیتال

یک قالب کارت ویزیت دیجیتال قابل شخصی‌سازی، با پنل مدیریت PHP، ذخیره‌سازی JSON و قابلیت نصب به‌صورت وب‌اپلیکیشن (PWA). این مخزن شامل نسخهٔ نمونه و پاک‌سازی‌شده است؛ اطلاعات نمایشی را با مشخصات خودتان جایگزین کنید.

</div>

# Digital Business Card

[Read this README in Persian](README.fa.md)

A self-hosted, Persian-first digital business card template with a PHP admin panel, JSON-based content storage, and Progressive Web App (PWA) support.

![Project preview](image/og-cover.jpg)

## Features

- Editable profile, biography, skills, contact methods, social links, and custom links.
- Sections for work experience, education, certifications, projects, gallery, location, and resume download.
- Admin panel with password-protected access, CSRF checks, session handling, and login-attempt throttling.
- Profile image, banner, gallery, and document upload workflows.
- Persian-first interface with English support and Jalali/Gregorian date handling.
- Theme and card appearance customization.
- Installable PWA with service-worker caching and offline fallback.
- Save the card as PNG and print or export it to PDF through the browser.
- No database is required; editable content is stored in JSON files.

## Tech stack

- PHP 8.1+ (server-side admin and utility endpoints)
- HTML5, CSS3, vanilla JavaScript
- JSON file storage
- Apache `.htaccess` rules for production hardening

## Requirements

- PHP 8.1 or newer
- PHP extensions: `mbstring` and `gd` (image upload processing); JSON and sessions must be enabled
- Apache is recommended for production so the included `.htaccess` protections and headers can be applied

## Run locally

1. Download or clone this repository.
2. Open a terminal in the project root.
3. Start PHP's built-in development server:

   ```bash
   php -S 127.0.0.1:8080 -t .
   ```

4. Open the card at `http://127.0.0.1:8080/`.
5. The admin login page is at `http://127.0.0.1:8080/admin/login.php`.

> PHP's built-in server does not process `.htaccess`. Use Apache for production and verify that `mod_rewrite` and `mod_headers` are enabled.

## Create the first admin account

The public repository intentionally does **not** include an admin account or password hash. Create `admin/auth_hash.php` on your own server before using the admin panel. This file is ignored by Git. The login page cannot create the first account while this file is missing, so create it manually once using the steps below.

1. Generate a bcrypt hash locally. This command reads the password from standard input, so the password itself is not part of the shell command:

   **PowerShell (Windows), Git Bash, macOS, and Linux:**

   ```powershell
   php -r '$password = trim(fgets(STDIN)); echo password_hash($password, PASSWORD_BCRYPT), PHP_EOL;'
   ```

   **Windows Command Prompt (cmd.exe):**

   ```bat
   php -r "$password = trim(fgets(STDIN)); echo password_hash($password, PASSWORD_BCRYPT), PHP_EOL;"
   ```

2. Create `admin/auth_hash.php` with the generated hash:

   ```php
   <?php
   return [
       'username' => 'choose-a-unique-username',
       'hash' => 'PASTE_THE_GENERATED_BCRYPT_HASH_HERE',
       'display_name' => 'Site Administrator',
   ];
   ```

3. Use the username and password you selected to sign in. Use a unique password and do not commit `admin/auth_hash.php`.

## Deploy to a PHP host

GitHub is used to store and present the source code. **GitHub Pages cannot run this project's PHP admin panel or PHP endpoints.** For a live, fully functional installation, deploy the repository to a PHP-capable host (Apache + PHP 8.1+ is the recommended baseline).

Before going live:

- Set a strong, unique admin password and keep `admin/auth_hash.php` out of version control.
- Ensure `data/` and `data/uploads/` are writable by PHP, using the narrowest permissions your host supports. The view counter creates `data/views.json` at runtime.
- Keep uploaded resumes and generated runtime data out of the public repository.
- Use HTTPS.
- Confirm the hosting provider applies the included `.htaccess` files; otherwise reproduce their access controls and security headers in the server configuration.
- Review and replace the demo content in `data/card.json` and `data/content-site.json`.
- Replace the placeholder Open Graph URL/image metadata with your real deployment URL if you need link previews.

## Repository structure

```text
admin/                 PHP admin panel and authentication helpers
css/                   UI tokens, typography and print styles
data/                  Demo JSON content and upload access rules
fonts/                 Empty public font catalog; add licensed fonts here
image/                 App icons and generic social preview artwork
js/                    Front-end rendering and interactions, including app-shell.js
tools/                 Optional font-catalog build utility
index.html             Public digital business card
manifest.json          PWA manifest
sw.js                  Service worker
views.php               Lightweight view counter endpoint
resume.php              Controlled resume-download endpoint
```

## Security and privacy notes

- The repository contains sanitized demo JSON, not a real person's business-card data.
- Admin credentials, secrets, uploaded media, and resume documents are excluded from version control.
- The initial ZIP contained a default `admin` / `admin` login. That credential file has been removed from this public-ready package; never publish the original ZIP unchanged.
- The supplied font binaries had mixed copyright notices and no complete redistribution licence bundle, so they were omitted. Add only fonts you are legally allowed to redistribute.
- Security-related controls are implemented in the source, but this package has not undergone an independent security audit.

## License

No open-source license is included yet. Until the project owner selects and adds a license, standard copyright restrictions apply; do not assume permission to reuse, redistribute, or modify the project.

## Version

`1.1.0`
